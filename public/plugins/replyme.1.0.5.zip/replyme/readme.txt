=== ReplyMe ===
Contributors: photozero
Donate link: http://photozero.net/
Tags: comments,email
Tested up to: 2.7
Stable tag: 1.0.5

Send a email to author automatically while someone reply his comment.

== Description ==

<p>
Send a email to author automatically while someone reply his comment.<br />
You can custom the content what you send.<br />
Note: You must enable threaded (nested) comments and deactivate the plugin like `Wordpress Thread Comment`.
</p>

Languages supported now:
<ul>
<li>Chinese - 中文 by <a href="http://photozero.net">Neekey</a>， <a href="http://photozero.net/replyme-news/">(中文使用说明)</a></li>
<li>English</li>
<li>Polish - Polski by <a href="http://luniewski.eu">Marcin Łuniewski</a></li>
<li>Swedish - Svenska by <a href="http://www.skottet.se/">Gabriel Modéus</a></li>
<li>Turkish - Türkçe by <a href="http://opereysin.com/">Opereysin</a>, <a href="http://opereysin.com/net-hafiyesi/1186-replyme-kullanim-kilavuzu/">ReplyMe Kullanım Kılavuzu</a></li>
</ul>

………………………………………………………

<p>* Please translate: 
There are some files under the plugin dir like `subject.en`,`message.en`.(No pot file)
It is the example text to send and WP will read it when you active the plugin first time.
Please edit it(use Notepad++, etc) and translate it into your language and 
rename it like `subject.it_IT`,`message.it_IT` with UTF-8 encoding and 
send to me if possibly.
</p>
<p>* Any problem please contact me zero[AT]photozero[DOT]net . Thank you very much!</p>

== Installation ==

1. Upload `/replyme/` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the `Plugins` menu in WordPress.
3. Go to `Settings` > `ReplyMe` to configurate it.