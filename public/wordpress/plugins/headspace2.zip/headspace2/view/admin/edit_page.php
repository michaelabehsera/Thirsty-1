<p id="jaxtag"><input type="text" name="tags_input" class="tags-input headspace-tags" id="tags-input" size="25" tabindex="3" value="<?php echo get_tags_to_edit( $post_ID ); ?>" /></p>
<div id="tagchecklist"></div>
