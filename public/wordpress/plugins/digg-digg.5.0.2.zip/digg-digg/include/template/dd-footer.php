<!--<div class="dd-block">
	<div class="dd-title"><h2>Premium WordPress Themes</h2></div>
	<div class="dd-insider">
		<div style="padding-right:8px;float:left;">
			<a href="http://mkyong.com/digg-digg/recommend-elegant-theme/" target="_blank">
				<img src='<?php echo DD_PLUGIN_URL ?>../image/ads/elegant-themes-300x250.gif' />
			</a>
		</div>
		
		<p>
			<strong>Digg Digg</strong> highly recommended <a target="_blank" href="http://mkyong.com/digg-digg/recommend-elegant-theme/" target="_blank">Elegant Themes</a>.
			They are attractive, compatible, affordable, SEO optimized and best support in community.
		</p>
		
		<p><strong>Beautiful themes, Great support!</strong></p>
		<div style="clear:both"></div>
	</div>
</div>
-->