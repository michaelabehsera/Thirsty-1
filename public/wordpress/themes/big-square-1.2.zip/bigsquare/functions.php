<?php
/**
 * @package Wordspop
 * @subpackage Fotofolio_Landscape
 */

add_theme_support('webfont');

/**
 * Load initial WPop script
 */
require_once dirname(__FILE__) . '/libs/wpop/init.php';
