Instructions: 

To enable the dropcap feature, simply use the shortcode [dropcap][/dropcap] around the first letter or word of the paragraph.

To create an archives page like the one in our demo, create a new page called "Archives", and apply the archives template from the template drop-down menu in the Page Attributes sidebar.

Changelog:

1.0.2 - Fixed spacing on dropcap CSS.
1.0.1 - Fixed web fonts to correctly support accented characters
1.0 - Original release