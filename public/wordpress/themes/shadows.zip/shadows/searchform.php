<form method="get" id="searchbar" action="<?php bloginfo('home'); ?>/">
<input type="text" size="16" name="s" id="search" value="Search" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" />
<input type="submit" value="search" id="searchsubmit" />
</form>