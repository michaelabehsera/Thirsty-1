<?php get_header(); ?>
    
    	<div id="post-wrap" class="full-width-wrap">
        		<h1 class="page-title">404 Error - Page Not Found</h1>			
				<p>Sorry, the page you were looking for could not be found</p>
        </div><!-- END post-wrap -->
     
<?php get_footer(); ?>