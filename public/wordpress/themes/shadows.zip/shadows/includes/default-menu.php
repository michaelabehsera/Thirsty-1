<ul class="sf-menu">					
	<li class="current_page_item"><a href="<?php bloginfo('url'); ?>/wp-admin/nav-menus.php">Set Up Your Menu</a></li>
</ul>